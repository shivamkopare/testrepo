function compute()
{
    p = document.getElementById("principal").value;
    
}
{
     r = document.getElementById("rate").value;
}       
{
     y = document.getElementById("years").value;
}
{
     i = principal * years * rate /100;
}
{
     y = new Date().getFullYear()+parseInt(years);
}
 function updateRate() 
{
    var rateval = document.getElementById("rate").value;
    document.getElementById("rate_val").innerText=rateval;
}